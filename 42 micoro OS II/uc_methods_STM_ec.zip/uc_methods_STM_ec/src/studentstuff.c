//////////////////////////////////////////////////////////////////////////////
// prog: studentstuff.c
// comm: for practicing purposes
// auth: Student:
//////////////////////////////////////////////////////////////////////////////

#include <includes.h>
#include "main.h"
#include "taskcreate.h"


#define LEDBLUE   GPIO_Pin_12
#define LEDRED    GPIO_Pin_13
#define LEDYELLOW GPIO_Pin_14
#define LEDGREEN  GPIO_Pin_15


//func: InitUserLED
//args: None (maybe option to specify LEDs)
//comm: PD12,PD13,PD14,PD15 GPIO are connected to the four leds from stm32
void InitUserLED(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;

	/*-------------------------- GPIO Configuration ----------------------------*/
	GPIO_InitStructure.GPIO_Pin = LEDBLUE | LEDRED | LEDYELLOW | LEDGREEN;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	GPIO_SetBits(GPIOD, LEDBLUE | LEDRED | LEDYELLOW | LEDGREEN); // set leds on
}

void toggle_led (uint32_t color)
{
	GPIO_ToggleBits(GPIOD, color); 	    // turns led on or off
    OSTimeDly(90); 						// time for other tasks
	GPIO_ToggleBits(GPIOD, color); 	    // turns led on or off
}


//////////////////////////////////////////////////////////////////////////////
// func: MijnTask1
// args: void *pdata, needed by os
// comm: oefencode
//////////////////////////////////////////////////////////////////////////////
void MijnTask1 (void *pdata)
{
	InitUserLED ();
	UART_puts("\n\r"); UART_puts((char *)__func__); UART_puts("started");

    while(TRUE)
    {
    	toggle_led (LEDBLUE);
    	toggle_led (LEDRED);
    	toggle_led (LEDYELLOW);
    	toggle_led (LEDGREEN);
    }
}


//////////////////////////////////////////////////////////////////////////////
// func: MijnTask2
// args: void *pdata, needed by os
// comm: oefencode
//////////////////////////////////////////////////////////////////////////////
void MijnTask2 (void *pdata)
{
	int  round = 1; // telt de rondjes
	int  i;         // teller

	UART_puts("\n\r"); UART_puts((char *)__func__); UART_puts("started");

    while(TRUE)
    {
    	for (i=0; i<255; i++)
    	{
    		LED_put(i);   // set leds
            OSTimeDly(5); // force contextswitch: time for other tasks
    	}
		UART_puts(" MijnTask2-round: ");
		UART_putint(round);
		UART_puts("\n\r");
        round++;

        OSTimeDly(LOOP_DELAY); // time for other tasks
    }
}

