//////////////////////////////////////////////////////////////////////////////
// prog: main.h
// comm: external definitions and prototypes for main
// auth: MSC
//////////////////////////////////////////////////////////////////////////////

// debug output stuff
#define OUTPUT_DEBUG

extern int Uart_debug_out; // bitmask-toggle key for task-debug-output
#define MUTEX_DEBUG_OUT   	0x01 // bit 1 used to toggle mutex-task output
#define MAILBOX_DEBUG_OUT 	0x02 // bit 2 used to toggle mbox-task output
#define FLAG_DEBUG_OUT    	0x04 // bit 3 used to toggle flag-task output
#define QUEUE_DEBUG_OUT   	0x08 // bit 4 used to toggle queue-task output
#define INTERRUPT_DEBUG_OUT 0x10 // bit 5 used to toggle interrupt-task output


#define WAIT_FOREVER        0   // to force all OSPends (flag, mutex, mbox etc.) to wait for incoming signal
#define LOOP_DELAY          60  // standard delay time for tasks
#define LED_DELAY           50  // to slow leds down
#define QSIZE               10  // 10 q-members


// priorities for all tasks and prty of mutex-semaphore itself
enum {
    INITTASK_PRTY = 5,

    MUTEX_PRTY = 8,       // careful, this one should be highest of all using tasks
    MUTEXTASK1_PRTY = 10,
    MUTEXTASK2_PRTY,
    MUTEXTASK3_PRTY,
    MUTEXTASK4_PRTY,

    MIJNTASK1_PRTY,

    MBOXPOSTTASK_PRTY,
    MBOXPENDTASK_PRTY,


    FLAGPOSTTASK_PRTY = 22,
    FLAGPENDTASK_PRTY,

    QUEUEPOSTTASK_PRTY,
    QUEUEPENDTASK_PRTY,

    INTERRUPTTASK_PRTY,

    DUMMY
};


// handles, used for semaphore, mailbox, flag, queue
// defined as a pointer; the os will allocate an OS_EVENT on it
extern OS_EVENT    *MutexHandle;
extern OS_EVENT    *MboxHandle;
extern OS_FLAG_GRP *FlagHandle;
extern OS_FLAG_GRP *FlagIntHandle;
extern OS_EVENT    *QueueHandle;

// q structure
typedef struct queue
{
 	int   nr;        // id-counter
 	int   round;     // id-round number
	char  text[17];  // text to display
} Q, *PQ;

extern Q     data_queue[]; // data queue, in this case array of Q-structs
extern void* os_queue[];   // pointer queue for OS


// function prototypes for various tasks to prevent compiler warnings
extern void InitTask      (void *pdata);
extern void InitMutex     (void);
extern void DisplayOSData (void);
extern void CreateHandles (void);
extern void displayAllStackData(void);
extern void hold_resume   (INT8U);

// function prototypes of threads/tasks/processes to prevent compiler warnings
extern void MijnTask1     (void *pdata);
extern void MutexTask1    (void *pdata);
extern void MutexTask2    (void *pdata);
extern void MutexTask3    (void *pdata);
extern void MutexTask4    (void *pdata);
extern void MboxPostTask  (void *pdata);
extern void MboxPendTask  (void *pdata);
extern void FlagPostTask  (void *pdata);
extern void FlagPendTask  (void *pdata);
extern void QueuePostTask (void *pdata);
extern void QueuePendTask (void *pdata);
extern void InterruptTask (void *pdata);

