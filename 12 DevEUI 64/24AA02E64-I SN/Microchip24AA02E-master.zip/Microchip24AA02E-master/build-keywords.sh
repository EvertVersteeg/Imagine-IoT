#!/bin/bash

exec python ./arduino-keywords/bin/arduino-keywords
