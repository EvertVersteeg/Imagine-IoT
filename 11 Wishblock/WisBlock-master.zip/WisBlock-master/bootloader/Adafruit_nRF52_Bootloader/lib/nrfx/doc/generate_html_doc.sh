rm -rf html
doxygen nrfx.doxyfile
